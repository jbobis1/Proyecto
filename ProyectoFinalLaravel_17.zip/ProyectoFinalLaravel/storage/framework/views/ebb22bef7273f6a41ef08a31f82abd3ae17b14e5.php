<!doctype html>
<html lang="en">

<head>

  <title>Editar Productos</title>

  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <!-- Bootstrap CSS v5.2.1 -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">
    <link rel="stylesheet" href="<?php echo e(asset('asset/estilos.css')); ?> ">


    <?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <?php $__env->startSection('content'); ?>

  
 <?php if(session()->has('success_msg')): ?>
     <div class="alert alert-success alert-dismissible fade show" role="alert">
         <?php echo e(session()->get('success_msg')); ?>

         <button type="button" class="close" data-dismiss="alert" aria-label="Close">
             <span aria-hidden="true">×</span>
         </button>
     </div>
 <?php endif; ?>
 <?php if(session()->has('alert_msg')): ?>
     <div class="alert alert-warning alert-dismissible fade show" role="alert">
         <?php echo e(session()->get('alert_msg')); ?>

         <button type="button" class="close" data-dismiss="alert" aria-label="Close">
             <span aria-hidden="true">×</span>
         </button>
     </div>
 <?php endif; ?>
 <?php if(count($errors) > 0): ?>
     <?php $__currentLoopData = $errors0>all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <div class="alert alert-success alert-dismissible fade show" role="alert">
             <?php echo e($error); ?>

             <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                 <span aria-hidden="true">×</span>
             </button>
         </div>
     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 <?php endif; ?>
         <?php $__env->slot('header', null, []); ?> 
    
         <?php $__env->endSlot(); ?>
        <div class="container" style="margin-top: 80px">
        
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="/">Inicio</a></li>
                <li class="breadcrumb-item"><a href="/shop">Tienda</a></li>
                <li class="breadcrumb-item active" aria-current="page">Editar Producto</li>
            </ol>
 
            <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
                <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                    
                        <div class="grid grid-cols-3 grid-rows-2">
                        </div>
                        <div class="table-responsive">
                        <table class="table">
  <thead class="thead-dark">
    <tr>
        
                                 
                                    <th cope="col">
                                    Nombre
                                    </th>
                      
                                    <th cope="col">
                                    Acciones
                                    </th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $carrera; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                     
                                        <td class="px-6 py-4">
                                            <?php echo e($u->name); ?>

                                        </td>
             
                                        <td class="px-6 py-4">
                                            <?php if(Auth::user()->admin): ?>
                                                <div class="btn-group" role="group" aria-label="Basic example">
                                                    <form class="inline-block"
                                                        action=<?php echo e(route('circuito.destroy', ['circuito' => $u->id])); ?>

                                                        method="POST">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>
                                                        <button class="btn btn-dark btn-sm" style="margin-right: 10px;"><i class="fa fa-trash"></i></button>
                                                    </form>
                                                    <?php endif; ?>
                                                    <a href=<?php echo e(route('circuito.edit', ['circuito' => $u->id])); ?> ><button class="btn btn-secondary btn-sm" style="margin-right: 25px;"><i class="fa fa-edit"></i></button></a>
                                                </div>
                                      
                                           
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
 <!-- Bootstrap JavaScript Libraries -->
 <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"
    integrity="sha384-oBqDVmMz9ATKxIep9tiCxS/Z9fNfEXiDAYTujMAeBAsjFuCZSmKbSSUnQlmh/jp3" crossorigin="anonymous">
  </script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.min.js"
    integrity="sha384-7VPbUDkoPSGFnVtYi0QogXtr74QeVeeIs99Qfg5YCF+TidwNdjvaKZX19NZ/e6oz" crossorigin="anonymous">
  </script>

</body>

</html><?php /**PATH C:\Users\javib\Downloads\Nueva carpeta\ProyectoFinalLaravel\resources\views/producto/index.blade.php ENDPATH**/ ?>