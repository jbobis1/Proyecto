
<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('puntuaciones')->html();
} elseif ($_instance->childHasBeenRendered('cCZx6Os')) {
    $componentId = $_instance->getRenderedChildComponentId('cCZx6Os');
    $componentTag = $_instance->getRenderedChildComponentTagName('cCZx6Os');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('cCZx6Os');
} else {
    $response = \Livewire\Livewire::mount('puntuaciones');
    $html = $response->html();
    $_instance->logRenderedChild('cCZx6Os', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php /**PATH C:\xampp\htdocs\ProyectoFinalLaravel\resources\views/PuntuacionPorJornada.blade.php ENDPATH**/ ?>