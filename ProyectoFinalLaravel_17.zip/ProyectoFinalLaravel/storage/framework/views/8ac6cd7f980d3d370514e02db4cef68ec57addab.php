
<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('ranking')->html();
} elseif ($_instance->childHasBeenRendered('83ln6Ta')) {
    $componentId = $_instance->getRenderedChildComponentId('83ln6Ta');
    $componentTag = $_instance->getRenderedChildComponentTagName('83ln6Ta');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('83ln6Ta');
} else {
    $response = \Livewire\Livewire::mount('ranking');
    $html = $response->html();
    $_instance->logRenderedChild('83ln6Ta', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php /**PATH C:\xampp\htdocs\ProyectoFinalLaravel\resources\views/MostrarRanking.blade.php ENDPATH**/ ?>