<div>
    <?php if($mostrar): ?>
    Bienvenido a crear puntuacion
    <?php endif; ?>
</div>
<?php /**PATH C:\xampp\htdocs\ProyectoFinalLaravel\resources\views/livewire/CrearPuntucion.blade.php ENDPATH**/ ?>