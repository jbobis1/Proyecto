<div>
    <?php $attributes = $attributes->exceptProps(['color' => 'blue', 'title' => '']); ?>
<?php foreach (array_filter((['color' => 'blue', 'title' => '']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

    <div class="alert bg-<?php echo e($color); ?>-100 border-t border-b border-<?php echo e($color); ?>-500 text-<?php echo e($color); ?>-700 px-4 py-3 relative" role="alert">
        <p class="font-bold"><?php echo e($title); ?></p>
        <p class="text-sm"><?php echo e($slot); ?></p>
    </div>
</div>
<?php /**PATH C:\Users\Antonio\Desktop\ProyectoFinalLaravel\resources\views/components/campo-texto.blade.php ENDPATH**/ ?>