<?php echo e($slot); ?>

<?php /**PATH C:\Users\javib\Downloads\Nueva carpeta\ProyectoFinalLaravel\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>