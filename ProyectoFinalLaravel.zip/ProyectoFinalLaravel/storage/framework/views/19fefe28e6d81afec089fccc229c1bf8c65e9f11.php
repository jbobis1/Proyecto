<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php if (isset($component)) { $__componentOriginalc2353cb572433e53b7f87b8b8f970309c7f0765d = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\CampoTexto::class, []); ?>
<?php $component->withName('campo-texto'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>Bienvenido <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc2353cb572433e53b7f87b8b8f970309c7f0765d)): ?>
<?php $component = $__componentOriginalc2353cb572433e53b7f87b8b8f970309c7f0765d; ?>
<?php unset($__componentOriginalc2353cb572433e53b7f87b8b8f970309c7f0765d); ?>
<?php endif; ?>
        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12 bg-blue-100">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">

            <div
                class="grid mb-8 border border-gray-200 rounded-lg shadow-sm dark:border-gray-700 md:mb-12 md:grid-cols-2">
                <figure
                    class="flex flex-col items-center justify-center p-8 text-center bg-white border-b border-gray-200 rounded-t-lg md:rounded-t-none md:rounded-tl-lg md:border-r dark:bg-gray-800 dark:border-gray-700">
                    <blockquote class="max-w-2xl mx-auto mb-4 text-gray-500 lg:mb-8 dark:text-gray-400">
                        <h3 class="text-lg font-semibold text-gray-900 dark:text-white">Bienvenido a MotoGP
                        </h3>
                        <p class="my-4 font-light">En nuestra pagina podras ver los equipos y las carreras</p>
                    </blockquote>
                    <figcaption class="flex items-center justify-center space-x-3">
                        <img class="rounded-full w-9 h-9"
                            src="https://th.bing.com/th?id=OSK.4c8b317e0411d3b8863dd69ef6b3b3a6&w=188&h=132&c=7&o=6&pid=SANGAM"
                            alt="profile picture">
                        <div class="space-y-0.5 font-medium dark:text-white text-left">
                            <div>MOTOGP</div>
                        </div>
                    </figcaption>
                </figure>

                <figure
                    class="flex flex-col items-center justify-center p-8 text-center bg-white border-b border-gray-200 rounded-bl-lg md:border-b-0 md:border-r dark:bg-gray-800 dark:border-gray-700">
                    <blockquote class="max-w-2xl mx-auto mb-4 text-gray-500 lg:mb-8 dark:text-gray-400">
                        <h3 class="text-lg font-semibold text-gray-900 dark:text-white">Quienes Somos</h3>
                        <p class="my-4 font-light">Gran fan de la motoGP y solo quiero compartir
                        </p>
                    </blockquote>
                    <figcaption class="flex items-center justify-center space-x-3">
                        <img class="rounded-full w-9 h-9"
                            src="https://th.bing.com/th/id/OIP.ABimqD7XQgKA1H5gF4P68QHaE7?pid=ImgDet&rs=1"
                            alt="profile picture">
                        <div class="space-y-0.5 font-medium dark:text-white text-left">
                            <div>Javier Bobis Montes</div>
                            <div class="text-sm font-light text-gray-500 dark:text-gray-400">Experto en competiciones de MotoGp desde 2008 hasta la actualidad</div>
                        </div>
                    </figcaption>
                </figure>

            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\Users\Antonio\Desktop\ProyectoFinalLaravel\resources\views/welcome.blade.php ENDPATH**/ ?>