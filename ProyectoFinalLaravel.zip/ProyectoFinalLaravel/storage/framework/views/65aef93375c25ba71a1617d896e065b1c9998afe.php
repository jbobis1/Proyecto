<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php if (isset($component)) { $__componentOriginalc2353cb572433e53b7f87b8b8f970309c7f0765d = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\CampoTexto::class, []); ?>
<?php $component->withName('campo-texto'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>caracteristicas del circuito <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc2353cb572433e53b7f87b8b8f970309c7f0765d)): ?>
<?php $component = $__componentOriginalc2353cb572433e53b7f87b8b8f970309c7f0765d; ?>
<?php unset($__componentOriginalc2353cb572433e53b7f87b8b8f970309c7f0765d); ?>
<?php endif; ?>
        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12 bg-blue-100">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 bg-white border-b border-gray-200">
                    <table class="w-full text-sm text-left text-gray-500 dark:text-gray-400">
                        <thead class="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
                            <tr>
                                <th class="px-6 py-3">
                                    ID
                                </th>
                                <th class="px-6 py-3">
                                    Nombre
                                </th>
                                <th class="px-6 py-3">
                                    Vueltas
                                </th>
                                <th class="px-6 py-3">
                                    Kms
                                </th>
                                <th class="px-6 py-3">
                                    Jornada
                                </th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr class="bg-white border-b dark:bg-gray-800 dark:border-gray-700">
                                <td class="px-6 py-4">
                                    <?php echo e($circuito->id); ?>

                                </td>
                                <td class="px-6 py-4">
                                    <?php echo e($circuito->nombre); ?>

                                </td>
                                <td class="px-6 py-4">
                                    <?php echo e($circuito->vueltas); ?>

                                </td>
                                <td class="px-6 py-4">
                                    <?php echo e($circuito->kmsVuelta); ?>

                                </td>
                                <td class="px-6 py-4">
                                    <?php echo e($circuito->Jornada); ?>

                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\Users\Antonio\Desktop\ProyectoFinalLaravel\resources\views/circuito/show.blade.php ENDPATH**/ ?>